package com.jyt.terminal.exception;

/**
 * 验证码错误异常
 *
 * @author fengshuonan
 * @date 2017-05-05 23:52
 */
public class InvalidKaptchaException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3695713178561350380L;
}
