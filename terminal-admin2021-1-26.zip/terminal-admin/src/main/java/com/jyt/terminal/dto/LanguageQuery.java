package com.jyt.terminal.dto;

/**
 * 多语言列表查询条件
 *
 * @author huoChangGuo
 * @since 2019/6/25
 */
public class LanguageQuery {
    private String keyword;

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }
}
