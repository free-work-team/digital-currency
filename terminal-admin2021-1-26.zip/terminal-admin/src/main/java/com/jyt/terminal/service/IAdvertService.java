package com.jyt.terminal.service;

import com.baomidou.mybatisplus.service.IService;
import com.jyt.terminal.model.Advert;

/**
 * 设置发送邮箱接口
 * @className IEmailSettingService
 * @author wangwei
 * @date 2019年9月10日
 *
 */
public interface IAdvertService extends IService<Advert>{
	
	

}
