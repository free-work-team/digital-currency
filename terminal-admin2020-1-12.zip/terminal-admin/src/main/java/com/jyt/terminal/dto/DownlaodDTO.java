package com.jyt.terminal.dto;

public class DownlaodDTO extends BaseObject{
	
	/**
     * 终端id
     */
    private String fileStr;

	public String getFileStr() {
		return fileStr;
	}

	public void setFileStr(String fileStr) {
		this.fileStr = fileStr;
	}
	
    
}
