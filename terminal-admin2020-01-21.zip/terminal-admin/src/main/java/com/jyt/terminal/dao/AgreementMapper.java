package com.jyt.terminal.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.jyt.terminal.model.Agreement;

/**
 * 协议接口
 * @className AgreementMapper
 * @author wangwei
 * @date 2019年11月20日
 *
 */
public interface AgreementMapper extends BaseMapper<Agreement>{

}
