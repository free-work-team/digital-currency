package com.jyt.terminal.service;

import com.baomidou.mybatisplus.service.IService;
import com.jyt.terminal.model.Agreement;

/**
 * 协议设置
 * @className IAgreementService
 * @author wangwei
 * @date 2019年11月20日
 *
 */
public interface IAgreementService extends IService<Agreement>{
	
}
