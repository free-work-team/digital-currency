package com.jyt.terminal.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.jyt.terminal.model.Advert;

/**
 * 广告设置接口
 * @className NotifyMailboxMapper
 * @author sunshubin
 * @date 2019年9月27日
 *
 */
public interface AdvertMapper extends BaseMapper<Advert>{

}
