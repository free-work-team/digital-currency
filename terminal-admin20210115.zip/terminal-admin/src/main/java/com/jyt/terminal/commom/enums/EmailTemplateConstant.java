package com.jyt.terminal.commom.enums;

public class EmailTemplateConstant {
	
	public static String KYC_REVIEW_SUCCESS= "KYC_REVIEW_SUCCESS";
	
	public static String KYC_REVIEW_FAIL= "KYC_REVIEW_FAIL";
	
	public static String KYC_SEND_CODE = "KYC_SEND_CODE";
	
	public static String KYC_SEND_MERCHANT = "KYC_SEND_MERCHANT";
	

}
